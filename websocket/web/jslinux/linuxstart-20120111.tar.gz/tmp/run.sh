#!/bin/sh
#get linux-2.6.20.tar from http://www.linux-mips.org/pub/linux/mips/kernel/v2.6/
#/usr/libexec/qemu-kvm  -kernel linux-2.6.20.jslinux/arch/i386/boot/bzImage -hda hda.bin -append "root=/dev/hda  console=ttyS0" -serial stdio -vnc 0.0.0.0:3
#/usr/libexec/qemu-kvm  -kernel linux-2.6.20.test/arch/i386/boot/bzImage -hda hda.bin -append "root=/dev/hda  console=ttyS0" -serial stdio -vnc 0.0.0.0:3
#/usr/libexec/qemu-kvm -S  -hda linux-0.2.img   -vnc 0.0.0.0:3
#ntpdate time.nist.gov
#http://wiki.qemu.org/Testing
#  
